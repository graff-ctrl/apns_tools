# APNS Tool

## Overview
This is a project developed for using collecting the Certs and Keys from a .p12 file and formatting them for use in our SecretsManger. 

## Setup
Download the binary from https://github.com/graff-ctrl/apns_tools/releases

run `pip install /{path to binary}`
